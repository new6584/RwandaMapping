/*
    Womble and Aurko present: map stuff
    this file creates a data module for an
    esri map application.

    We use ESRI's API which can be found here: https://developers.arcgis.com/javascript/
    Should read up on Dojo as well specifically their declare statement (class creator):  http://dojotoolkit.org/documentation/tutorials/1.10/modules/index.html
    I'm writing this as much to remind me to do it, but there is a... DESIGN DOC somehwere, unless we never actually do that...
    Again, so I remember, hopefully, the first time a process is introduced ill try and comment in why / what its doing
    especially in a place where you would need to change something if you are making your own application for BT,
    which shouldn't be happening in this file, unless there is a query you want to add i guess
    
    layer names need to be unqiue

    expected callback name is: GetMe
    -----------------events--------------------
        dataFail : non destructive error
        datsError : destructive error
        isReady : map has loaded 
        dataRetrieval : query success
    --------------------------------------------

    initializes the map object based on what is passed in the constructor 
    ( arcgisOnline map Id, arcgis rest service tile layer uri, ID of the DOM element to put the map in)
    if you want to make changes to the map's options, i recommend leveraging .myMap in your business layer

*/




define([//think of this as a java import statment
    "dojo/_base/declare",
    "dojo/Evented",
    "esri/map",
    "esri/arcgis/utils",
    "esri/tasks/QueryTask",
    "esri/tasks/query",
    "esri/geometry/Point",
    "dojo/domReady!"//no callback 
],
function (//callbacks for those 'import statments' above
    declare,
    Evented,
    Map,
    esriUtils,
    QueryTask,
    Query,
    Point

) {
    return declare([Evented], {//make a class that 'extends' evented

        mapID: null,
        restService: null,
        myMap: null,
        layerNameAndID: null,
		restURI:null,

        constructor: function (_mapID,_tileURI,mapDiv) {
            this.mapID = _mapID;
            this.restService = "http://www.arcgis.com/sharing/rest/content/items";
            this.restURI = "https://services2.arcgis.com/RQcpPaCpMAXzUI5g/arcgis/rest/services/Kigeme/FeatureServer/";
            this.aNewMap(mapDiv, _tileURI);
            layerNameAndID = [];
        },
        /*
         * creates map based on constructors parameters
         * adds properties and tiles
         * check for isReady to know when we're done and this 'class'
         * is ready to be used
         */
        aNewMap: function (mapDiv,myTiles) {
            var self = this;//scoping
            esriUtils.arcgisUrl = this.restService;
            esriUtils.createMap(this.mapID, mapDiv).then(function (response) {
                self.myMap = response.map;
                self.myMap.disableDoubleClickZoom();
                self.myMap.addLayer(new esri.layers.ArcGISTiledMapServiceLayer(myTiles));
                self.myMap.on('click', function (evt) { 
                    self.pclickHandler('facilities', evt);//this is for testing
                });
                //pInit methods 
                self.psetLayerNameToID();
                //send event isReady with no callback
                self.emit("isReady", {});
            });
        },
        /*
         * pulls the layer names from the map
         * returns them as an array of strings
         */
        theLayerNames: function () {
            var layerNames = [];
            for (var i = 0; i < this.layerNameAndID.length; i++) {
                layerNames.push(this.layerNameAndID[i].name);
            }
            return layerNames;
        },
        /* 
         * creates a sql query for psendQuery
         * getWhat: array of desired fields 
         * whereClause: sql where clause
         * layerName: name of layer to query
         * EG: select getWhat from layerName where whereClause;
         */
        layerData: function (getWhat, whereClause, layerName) {
            var query = new Query();
            query.outFields = getWhat;
            query.where = whereClause;
            this.psendQuery(layerName, query);
        },
		/*
			get rest service's image source
			returns an array of all image sources
			attached to passed object data
		*/
        theAttachments(layerName, objectID) {
			var root = this.restURI + this.pnameToID(layerName) + "/" + objectID + "/attachments/"
			var imageJson = root + "?f=pjson&token="; //query this for attachmentInfos[i].id
			var self = this;
			$.getJSON(imageJson).done(function (response) {
			    var imgSrcs = [];
			    for (var i = 0; i < response.attachmentInfos.length ; i++) {
			        imgSrcs.push( root + response.attachmentInfos[i].id );
			    }
			    self.emit('newAttachments',imgSrcs);
			});
			
		},

/*
* the following should be considered 'private' methods
* this is denoted with the 'method call' starting with a p
*
*/
        //{LAYER ID}/{OBJECTID}/attachments/{attachment id}
        psendQuery: function (layerName, queryObject, updateAttachments) {
            var layerID = this.pTranslateLayerName(layerName);
            if (!layerID) {
                this.emit('dataError', { error: 'layer name not found' });
                return null;
            }
            queryObject.outSpatialReference = this.myMap.spatialReference;
            queryObject.returnGeometry = false;

            var url = this.myMap.getLayer(layerID).url;//get url of selected layer
            var queryTask = new QueryTask(url);
            var self = this;
            queryTask.execute(queryObject, function (results) {//each index in features is a different dataset not a different feature
                if (results.features.length != 0) {//if there is data at clicked location
                    //returns only the data we care about from the query. if the features use associate tables need to link it to the value in fields
                    if (updateAttachments) {
                       self.theAttachments(layerName, results.features[0].attributes.OBJECTID);
                    }
                    
                    self.emit('dataRetrieval', { features: results.features, fields: results.fields });
                } else {
                    self.emit('dataFail', { error: 'results not found' });
                }

            });
        },


        /*
         * event handler for on click event
         * queries for data on the passed layer at the point clicked 
         */
        pclickHandler: function (layerName, event) {
            
            var point = event.mapPoint;
            qGeom = this.pmakeGeometryExtent(point);
            var query = new Query();
            query.geometry = qGeom;          
            query.outFields = ['*'];
            this.psendQuery(layerName,query,true);           
        },
        /*
         *helper function for reading click locations
         * padds radius to about mouse size. this is esri's recomended algorithm. 
         * Depending on prefered zoom level might require some editing though not recommended
         * we played with it some and had some very strange selection areas, think esri knows better
         */
        pmakeGeometryExtent(point) {
            pxWidth = this.myMap.extent.getWidth() / this.myMap.width;
            padding = 4 * pxWidth;
            return new esri.geometry.Extent({
                "xmin": point.x - padding,
                "ymin": point.y - padding,
                "xmax": point.x + padding,
                "ymax": point.y + padding,
                "spatialReference": point.spatialReference
            });
        },
        /*
         * sets layerNameAndID variale
         * {name: LAYER NAME, id: LAYER ID }
         * does this for all graphics layers
         */
        psetLayerNameToID: function () {
            var layerIDs = this.myMap.graphicsLayerIds;
            this.layerNameAndID = [];
            for (var i = 0; i < layerIDs.length; i++) {
                var jsonData = this.myMap.getLayer(layerIDs[i])._json;
                jsonData = JSON.parse(jsonData);
                //save as name : ID pairs. we want to user to see the names,
                //but we need the ID to call for more data so we'll store them together
                var temp = { id: layerIDs[i], name: jsonData.name, index: jsonData.id };
                this.layerNameAndID.push(temp);
                
            }
        },
		pnameToID: function(layerName){
			var self = this;
            for (var i = 0; i < self.layerNameAndID.length; i++) {
                if (self.layerNameAndID[i].name == layerName) {
                    return self.layerNameAndID[i].index;
                }
            }
            return null;
		},
        /*
         * returns the layer id associatiated with the passed name
         * or null if DNE
         */
        pTranslateLayerName: function (which) {
            var self = this;
            for (var i = 0; i < self.layerNameAndID.length; i++) {
                if (self.layerNameAndID[i].name == which) {
                    return self.layerNameAndID[i].id;
                }
            }
            return null;
        }

    });
});

