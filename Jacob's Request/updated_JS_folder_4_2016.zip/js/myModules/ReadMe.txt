Dojo Module Scripts

They're intended to make javascript more object oriented.

DataRequest houses the map location information, and getting data from esri